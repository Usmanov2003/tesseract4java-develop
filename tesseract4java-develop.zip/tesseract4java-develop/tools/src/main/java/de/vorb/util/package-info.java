/**
 * Common utilities.
 *
 * @author Paul Vorbach
 */
package de.vorb.util;

