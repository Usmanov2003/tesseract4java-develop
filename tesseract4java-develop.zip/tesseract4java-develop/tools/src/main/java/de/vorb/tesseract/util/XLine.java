package de.vorb.tesseract.util;

public class XLine extends Baseline {
    public XLine(int yOffset, float slope) {
        super(yOffset, slope);
    }
}
