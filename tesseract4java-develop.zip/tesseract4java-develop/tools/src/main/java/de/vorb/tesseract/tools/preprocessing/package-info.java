/**
 * Pre-processing tools.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.tools.preprocessing;
