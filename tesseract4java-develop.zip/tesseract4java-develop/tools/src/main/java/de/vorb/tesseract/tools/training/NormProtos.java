package de.vorb.tesseract.tools.training;

public class NormProtos {

}
