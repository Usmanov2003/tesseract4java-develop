/**
 * Recognition related tools.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.tools.recognition;
