package de.vorb.tesseract.util;

public class Baseline extends Straight {
    public Baseline(int yOffset, float slope) {
        super(yOffset, slope);
    }
}
