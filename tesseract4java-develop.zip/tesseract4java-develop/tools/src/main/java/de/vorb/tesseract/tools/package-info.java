/**
 * Tesseract.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.tools;

