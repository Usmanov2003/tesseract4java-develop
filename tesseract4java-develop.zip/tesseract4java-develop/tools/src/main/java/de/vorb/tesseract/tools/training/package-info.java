/**
 * Tesseract training.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.tools.training;

