package de.vorb.tesseract.tools.preprocessing.conncomp;

public interface ConnectedComponentFilter {
    boolean filter(ConnectedComponent connComp);
}
