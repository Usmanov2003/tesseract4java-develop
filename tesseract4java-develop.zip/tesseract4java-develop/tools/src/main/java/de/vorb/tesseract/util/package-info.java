/**
 * Utilities for the Tesseract tools.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.util;

