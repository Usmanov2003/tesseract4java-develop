package de.vorb.tesseract.tools.preprocessing.conncomp;

public enum Connectivity {
    FOUR, EIGHT
}
