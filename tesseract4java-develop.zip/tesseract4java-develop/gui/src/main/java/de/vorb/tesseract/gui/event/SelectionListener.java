package de.vorb.tesseract.gui.event;

public interface SelectionListener {
    void selectionChanged(int index);
}
