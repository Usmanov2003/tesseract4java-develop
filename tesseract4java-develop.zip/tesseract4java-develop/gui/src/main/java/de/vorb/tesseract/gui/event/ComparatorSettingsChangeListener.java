package de.vorb.tesseract.gui.event;

public interface ComparatorSettingsChangeListener {
    void settingsChanged();
}
