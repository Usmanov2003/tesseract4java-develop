/**
 * @author Paul Vorbach
 */
/**
 * @author Paul Vorbach
 *
 */
package de.vorb.tesseract.gui.event;
