/**
 * Controller classes for TesseractGUI.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.gui.controller;
