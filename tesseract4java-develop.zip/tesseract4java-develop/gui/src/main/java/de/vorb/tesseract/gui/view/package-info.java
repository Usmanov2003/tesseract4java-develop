/**
 * @author Paul Vorbach
 */
package de.vorb.tesseract.gui.view;
