package de.vorb.tesseract.gui.event;

public interface PageChangeListener {
    void pageSelectionChanged(int pageIndex);
}
