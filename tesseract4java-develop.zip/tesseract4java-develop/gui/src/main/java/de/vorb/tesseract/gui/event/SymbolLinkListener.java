package de.vorb.tesseract.gui.event;

import de.vorb.tesseract.util.Symbol;

public interface SymbolLinkListener {
    void selectedSymbol(Symbol symbol);
}
