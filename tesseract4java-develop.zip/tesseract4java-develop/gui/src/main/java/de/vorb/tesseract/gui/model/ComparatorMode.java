package de.vorb.tesseract.gui.model;

public enum ComparatorMode {
    COMPARE_SCAN_HOCR,
    COMPARE_HOCR_HOCR
}
