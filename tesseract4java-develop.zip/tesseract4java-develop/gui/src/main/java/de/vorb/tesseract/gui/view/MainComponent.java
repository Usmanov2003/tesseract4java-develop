package de.vorb.tesseract.gui.view;

import java.awt.Component;

public interface MainComponent {
    Component asComponent();

    void freeResources();
}
