/**
 * Model classes.
 *
 * @author Paul Vorbach
 */
package de.vorb.tesseract.gui.model;
