package de.vorb.tesseract.gui.model;

public enum ApplicationMode {
    NONE,
    PROJECT,
    BOX_FILE
}
